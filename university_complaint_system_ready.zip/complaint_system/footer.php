</div>
    <footer class="bg-dark text-white text-center py-3 mt-4">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Complaint Management System. All rights reserved.</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>